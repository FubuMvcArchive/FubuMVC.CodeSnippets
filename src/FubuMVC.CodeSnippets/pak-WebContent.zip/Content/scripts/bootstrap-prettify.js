﻿$(document).ready(function () {
    prettyPrint();
});